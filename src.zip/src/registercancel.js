import React from 'react'
import '../App.css'
const Registercancel = () => {
  return (
    <div className='headerreg'>
        <button className='button'>cancel</button>
        <button className='button'>Register</button>
    </div>

  )
}

export default Registercancel